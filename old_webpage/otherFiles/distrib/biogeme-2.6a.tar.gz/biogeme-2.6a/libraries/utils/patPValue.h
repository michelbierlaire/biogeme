//-*-c++-*------------------------------------------------------------
//
// File name : patPValue.h
// Author :    \URL[Michel Bierlaire]{http://roso.epfl.ch/mbi}
// Date :      Wed Jun 14 22:00:17 2006
//
//--------------------------------------------------------------------

#ifndef patPValue_h
#define patPValue_h

#include "patError.h"

/**
 */
patReal patPValue(patReal test, patError*& err) ;

#endif
