//-*-c++-*------------------------------------------------------------
//
// File name : trVector.h
// Author :    \URL[Michel Bierlaire]{http://rosowww.epfl.ch/mbi}
// Date :      Wed Jan 19 16:04:09 2000
//
//--------------------------------------------------------------------

#ifndef trVector_h
#define trVector_h

#include "patVariables.h"

/**
 */
typedef patVariables trVector ;

#endif
