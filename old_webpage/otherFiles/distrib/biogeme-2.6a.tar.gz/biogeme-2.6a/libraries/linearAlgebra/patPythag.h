//-*-c++-*------------------------------------------------------------
//
// File name : patPythag.h
// Author :    \URL[Michel Bierlaire]{http://rosowww.epfl.ch/mbi}
// Date :      Mon Aug 15 17:14:41 2005
//
//--------------------------------------------------------------------

#ifndef patPythag_h
#define patPythag_h

#include "patType.h"

patReal patPythag(const patReal a, const patReal b) ;

#endif
