//-*-c++-*------------------------------------------------------------
//
// File name : patArithNot.h
// Author :    \URL[Michel Bierlaire]{http://rosowww.epfl.ch/mbi}
// Date :      Thu Nov 23 15:11:23 2000
//
//--------------------------------------------------------------------

#ifndef patArithNot_h
#define patArithNot_h

#include "patArithNode.h"

/**
   @doc This class implements a node of the tree representing a logical not operation. A value of 0 is interpreted as FALSE, a value different from zero is interpreted as TRUE.
   @author \URL[Michel Bierlaire]{http://rosowww.epfl.ch/mbi}, EPFL (Wed Nov 22 16:45:45 2000) 
   @see patArithExpression, patArithNode 
*/

class patArithNot : public patArithNode {

public:
  
  /**
   */
  patArithNot(patArithNode* par,
	      patArithNode* left) ;

  /**
   */
  ~patArithNot() ;

  /**
   */
  virtual patOperatorType getOperatorType() const ;

  /**
     @return '!'
   */
  virtual patString getOperatorName() const;



  /**
     @return value of the expression
   */
  virtual patReal getValue(patError*& err) const  ;
    
  /**
     @return value of the derivative w.r.t variable x[index]
     @param index index of the variable involved in the derivative
     @param err ref. of the pointer to the error object.
   */
  patReal getDerivative(unsigned long index, patError*& err) const ;

  /**
     @return printed expression
   */

  virtual patString getExpression(patError*& err) const ;

  /**
     Get a deep copy of the expression
   */
  virtual patArithNot* getDeepCopy(patError*& err) ;
  /**
   */
   patString getCppCode(patError*& err) ;
  /**
   */
  patString getCppDerivativeCode(unsigned long index, patError*& err)  ;
};
#endif

