#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include "patBiogemeScripting.h" 

int main(int argc, char *argv[]) {

  patBiogemeScripting theMain ;
  theMain.mod2py(argc,argv) ;
}

