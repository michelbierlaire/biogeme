

        

        

        return f, g, h        
