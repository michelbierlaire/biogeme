files = ['05_01.py',
         '05_02.py',
         '05_03.py',
         '05_04.py',
         '05_05.py',
         '05_06.py',
         '05_07.py',
         '05_08.py',
         '05_09.py',
         '05_10.py',
         '05_11.py',
         '05_12.py',
         '05_13.py']

print(f'There {len(files)} files')

for f in files:
    name = f.rsplit('.', 1)[0]
    print(name)
    content = (f'#!/bin/bash -l\n'
               f'#SBATCH --chdir /home/bierlair/examples/swissmetro\n'
               f'#SBATCH --nodes 1\n'
               f'#SBATCH --ntasks 1\n'
               f'#SBATCH --cpus-per-task 24\n'
               f'#SBATCH --mem 192000\n'
               f'#SBATCH --time 20:00:00\n'
               f'\n'
               f'source ~/env_biogeme/bin/activate\n'
               f'echo STARTING AT `date`\n'
               f'echo {name}\n'
               f'srun python -u {name}.py\n'
               f'echo FINISHED AT `date`\n')
    ff = open(f'{name}.run', 'w')
    ff.write(content)
    ff.close()
