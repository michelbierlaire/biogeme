Biogeme is an open source freeware designed for the maximum likelihood
estimation of parametric models in general, with a special emphasis on
discrete choice models.


