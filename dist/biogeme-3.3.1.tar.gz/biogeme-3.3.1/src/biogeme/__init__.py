"""Biogeme is an open source Python package designed for the maximum
likelihood estimation of parametric models in general, with a special
emphasis on discrete choice models.

"""
