//-*-c++-*------------------------------------------------------------
//
// File name : bioExceptions.cc
// @date   Fri Apr 13 09:38:04 2018
// @author Michel Bierlaire
// @version Revision 1.0
//
//--------------------------------------------------------------------

#include <sstream>
#include "bioExceptions.h"



