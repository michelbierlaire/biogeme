"""Defines some constants used throughout the code"""

LOG_LIKE: str = 'log_like'
WEIGHT: str = 'weight'
