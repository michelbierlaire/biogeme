"""bierlaire_optimization is a collection of optimization algorithms
used for research and teaching

"""
