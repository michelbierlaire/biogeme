//-*-c++-*------------------------------------------------------------
//
// File name : bioIterationBackup.cc
// Author:     Michel Bierlaire, EPFL
// Date  :     Thu Oct 28 11:47:36 2010
//
//--------------------------------------------------------------------

#include "patDisplay.h"
#include "bioIterationBackup.h"

void bioIterationBackup::saveCurrentIteration() {
  //  WARNING("Not implemented") ;
}
