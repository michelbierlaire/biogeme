//-*-c++-*------------------------------------------------------------
//
// File name : patUniform.cc
// Author :    Michel Bierlaire
// Date :      Sun Aug 24 17:14:05 2014
//
//--------------------------------------------------------------------

#include "patUniform.h"

patUniform::~patUniform() {

}
